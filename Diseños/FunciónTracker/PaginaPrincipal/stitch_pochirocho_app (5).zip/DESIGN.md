---
name: Aura Kinetic
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0e0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#e8bcbe'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#ae8789'
  outline-variant: '#5e3e41'
  surface-tint: '#ffb2b8'
  primary: '#ffb2b8'
  on-primary: '#67001d'
  primary-container: '#ff506e'
  on-primary-container: '#5b0018'
  inverse-primary: '#be003d'
  secondary: '#7dffa2'
  on-secondary: '#003918'
  secondary-container: '#05e777'
  on-secondary-container: '#00622e'
  tertiary: '#ffb950'
  on-tertiary: '#452b00'
  tertiary-container: '#c58300'
  on-tertiary-container: '#3c2500'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdadb'
  primary-fixed-dim: '#ffb2b8'
  on-primary-fixed: '#40000f'
  on-primary-fixed-variant: '#91002d'
  secondary-fixed: '#62ff96'
  secondary-fixed-dim: '#00e475'
  on-secondary-fixed: '#00210b'
  on-secondary-fixed-variant: '#005226'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#ffb950'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  data-point:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 22px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 48px
  container-max: 1200px
---

## Brand & Style

This design system embodies a "Futuristic Bio-Digital" aesthetic, blending the precision of high-tech interfaces with the organic fluidity of biological systems. It is designed for a health and lifestyle super-app that feels like a living companion rather than a static tool.

The visual language is rooted in **Glassmorphism** and **Vaporwave-inspired futurism**. It utilizes a deep, infinite space-black foundation contrasted by high-vibrancy "aura" glows that signify different health modules. The UI should evoke a sense of calm intelligence, mystery, and vitality. Key characteristics include:
- **Organic Fluidity:** Connections between UI elements use metaball-inspired "gooey" transitions.
- **Luminance as Information:** Color and glow intensity represent data density and system status.
- **Textural Depth:** A persistent fine dot-matrix grid provides a tactile, "digitized" feel to the void.

## Colors

The palette is defined by high-chroma accents set against a monolithic dark background. 

- **Deep Space Black (#0B0E14):** The primary canvas, providing infinite depth.
- **Crimson/Magenta:** Used for vital biological tracking, such as heart rate or cycle tracking.
- **Emerald Green:** Represents growth, task completion, and general wellness.
- **Golden Amber:** Denotes energy levels, upcoming events, or warm notifications.
- **Lime/Solar Yellow:** The highest visibility color, used for primary calls to action or critical alerts.
- **Metallic Silver:** Used for secondary text, iconography, and decorative "circuitry" lines.

Each color should be paired with a corresponding 20-40px blurred "aura" glow when used in interactive or status-indicating components.

## Typography

The typography strategy balances friendly approachability with technical precision. 

**Be Vietnam Pro** is used for all narrative and interface text. Its contemporary, clean curves feel humane and modern. 
**Space Grotesk** is used exclusively for labels, data points, and technical metadata. Its geometric, slightly quirky construction reinforces the futuristic, scientific nature of the health data.

Large displays and headlines should use tight letter-spacing for a confident, editorial look. Labels should always be tracked out slightly to ensure legibility against the dark, high-contrast background.

## Layout & Spacing

The design system utilizes a **Fluid Grid** with a strict 4px baseline. 

- **Mobile:** A 4-column layout with 20px side margins. Elements often use "safe area" padding to float within the dot-matrix background.
- **Desktop/Tablet:** A 12-column layout centered within a max-width container. 
- **The "Hub" Layout:** A central feature of the application is the organic hub-and-spoke model. This layout ignores traditional grid constraints for the primary navigation, using a central "Orb" and satellite nodes connected by fluid gradients.
- **Padding:** Content containers should use generous internal padding (min 24px) to allow the glassmorphic background blurs enough surface area to be visible.

## Elevation & Depth

Depth is not communicated through traditional shadows, but through **light emission and opacity**.

1.  **Base Layer:** The #0B0E14 background with a subtle 2% opacity white dot-matrix pattern.
2.  **Surface Layer:** Semi-transparent "Glass" cards (White at 5-10% opacity) with a `backdrop-filter: blur(20px)`.
3.  **Accent Layer:** Glows and Auras. These sit *behind* the glass surfaces or emanate from icons. Use `box-shadow: 0 0 30px [color]opacity(0.4)`.
4.  **Interactive Layer:** High-luminance elements (Lime Yellow) that appear to sit closest to the glass, often featuring a subtle inner-glow to suggest volume.

## Shapes

The shape language is dominated by **perfect circles and hyper-rounded rectangles (pill shapes)**.

Sharp corners are entirely avoided to maintain the "organic" brand narrative. Small components (chips, inputs) use a 1rem radius, while larger cards use 2rem or 3rem to create a "container" feel. The primary navigation nodes should always be circular to represent biological cells or celestial bodies.

## Components

### Buttons
- **Primary:** Pill-shaped, Solid Solar Yellow (#C6FF00) with black text. No shadow, but a subtle "energy" glow on hover.
- **Secondary:** Glass-textured pill with a 1px Metallic Silver border.
- **Icon Buttons:** Circular glass discs with centered monochromatic icons.

### Cards & Modules
Cards must use `backdrop-filter: blur(24px)` and a subtle 1px border at 15% opacity white to define the edges against the black void. Content within cards should be strictly aligned to the internal 4px grid.

### Health Nodes (The Hub)
The central navigation components are circular orbs. Each orb has a radial gradient: `radial-gradient(circle at 30% 30%, [color] 0%, transparent 80%)`. They are connected by "tendrils"—fluid, tapered lines that share the gradient of the connected nodes.

### Input Fields
Inputs are bottom-aligned with a simple silver stroke that glows when focused. Labels use the `label-caps` typography style, positioned above the input line.

### Data Visualization
Use "Glow-lines" for charts—1.5pt strokes with a 4pt blur of the same color underneath to simulate neon tubing. Avoid solid fills; use gradients that fade into the background.